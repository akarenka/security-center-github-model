import os
import shutil
import tempfile

from security_system import SecuritySystem
from sandbox_drill import EnhancedSandboxDrill


def clean():
    for folder in ["temp_work", "quarantine_zone"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)


def run_all_tests():
    print("=== All Features Test: Manual Remove Only ===")
    clean()

    print("\n[1] SecuritySystem SQLite")
    db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    db.close()
    system = SecuritySystem(db.name)

    ok, msg = system.add_whitelist("trusted_app.exe")
    print("[Whitelist Add]", ok, msg)
    print("[Whitelist List]", system.get_whitelist())

    print("\n[1b] Whitelist manual remove")
    removed = system.remove_whitelist("trusted_app.exe")
    print("[Whitelist Remove]", removed)
    print("[Whitelist List After Remove]", system.get_whitelist())

    print("\n[1c] Whitelist manual add again and manual remove again")
    ok, msg = system.add_whitelist("manual_added_app.exe")
    print("[Whitelist Manual Add]", ok, msg)
    print("[Whitelist Manual Add List]", system.get_whitelist())
    removed_again = system.remove_whitelist("manual_added_app.exe")
    print("[Whitelist Manual Remove Again]", removed_again)
    print("[Whitelist Final List]", system.get_whitelist())

    ok, msg = system.add_threat("Demo", "Demo.Threat", "Low")
    print("[Threat Add]", ok, msg)
    print("[Threat Count]", len(system.get_threats()))

    print("\n[2] Sandbox normal scan")
    drill = EnhancedSandboxDrill(manual_game_mode=False)
    files = drill.create_test_environment("temp_work")
    print("[Create]", files)
    result = drill.scan_and_quarantine("temp_work")
    print("[Scan]", result["message"])
    print("[Game Mode]", result["game_mode"])
    print("[Quarantine]", drill.list_quarantine())

    print("\n[3] Clean quarantine")
    clean_result = drill.clean_expired_files(days=0)
    print("[Clean]", clean_result["message"])

    print("\n[4] Manual game mode skip")
    clean()
    game_drill = EnhancedSandboxDrill(manual_game_mode=True)
    game_drill.create_test_environment("temp_work")
    game_result = game_drill.scan_and_quarantine("temp_work")
    print("[Game Scan]", game_result["message"])
    print("[Game Mode]", game_result["game_mode"])
    print("[Quarantine]", game_drill.list_quarantine())

    print("\n[5] Recovery")
    recovery = game_drill.perform_system_recovery()
    for step in recovery["steps"]:
        print("[Recovery]", step)

    print("\n=== Result ===")
    print("Manual whitelist remove:", removed and removed_again)
    print("Normal quarantined:", len(result["quarantined"]))
    print("Manual game mode skipped:", game_result["game_mode"])
    print("PASS")


if __name__ == "__main__":
    run_all_tests()
