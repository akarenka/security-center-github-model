import os
import shutil
import time
from pathlib import Path


class SandboxDrill:
    def __init__(self, quarantine_dir="quarantine_zone"):
        self.quarantine_dir = Path(quarantine_dir)
        self.quarantine_dir.mkdir(exist_ok=True)
        self.signatures = [
            "EICAR-STANDARD-ANTIVIRUS-TEST-FILE",
            "Virus.Win32.Eicar",
        ]

    def create_test_environment(self, work_dir="temp_work"):
        work = Path(work_dir)
        work.mkdir(exist_ok=True)

        eicar_file = work / "Virus.Win32.Eicar"
        normal_file = work / "normal_file.txt"
        eicar_string = r"X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

        eicar_file.write_text(eicar_string, encoding="utf-8")
        normal_file.write_text("This is a normal test file.", encoding="utf-8")
        return [str(eicar_file), str(normal_file)]

    def is_threat(self, file_path):
        path = Path(file_path)

        if any(sig.lower() in path.name.lower() for sig in self.signatures):
            return True

        try:
            if path.stat().st_size > 1024 * 1024:
                return False
            content = path.read_text(encoding="utf-8", errors="ignore")
            return any(sig in content for sig in self.signatures)
        except Exception:
            return False

    def scan_and_quarantine(self, target_dir):
        target = Path(target_dir)
        if not target.exists():
            return {
                "ok": False,
                "game_mode": False,
                "message": f"Folder not found: {target}",
                "quarantined": [],
            }

        quarantined = []
        for root, dirs, files in os.walk(target):
            for filename in files:
                file_path = Path(root) / filename
                if self.is_threat(file_path):
                    destination = self.quarantine_dir / f"{int(time.time())}_{filename}"
                    shutil.move(str(file_path), str(destination))
                    quarantined.append(str(destination))

        return {
            "ok": True,
            "game_mode": False,
            "message": f"Quarantined {len(quarantined)} item(s)." if quarantined else "No threats detected.",
            "quarantined": quarantined,
        }

    def list_quarantine(self):
        return [item.name for item in sorted(self.quarantine_dir.iterdir()) if item.is_file()]

    def perform_system_recovery(self):
        return {
            "ok": True,
            "steps": [
                "Check quarantine status",
                "Check configuration integrity",
                "Refresh security status",
                "System recovery demo completed",
            ],
            "message": "System recovery demo completed.",
        }

    def clean_expired_files(self, days=7):
        now = time.time()
        max_age = days * 24 * 60 * 60
        removed = []

        for item in self.quarantine_dir.iterdir():
            if not item.is_file():
                continue
            age = now - item.stat().st_mtime
            if days == 0 or age >= max_age:
                item.unlink()
                removed.append(item.name)

        return {
            "ok": True,
            "removed": removed,
            "message": f"Cleaned {len(removed)} quarantined file(s)." if removed else "No quarantined files to clean.",
        }

    def reset_demo_environment(self, work_dir="temp_work"):
        for folder in [work_dir, str(self.quarantine_dir)]:
            p = Path(folder)
            if p.exists():
                shutil.rmtree(p)
        self.quarantine_dir.mkdir(exist_ok=True)
        return True


class EnhancedSandboxDrill(SandboxDrill):
    """
    No-psutil version.

    Game mode is manual only:
    - ON: skip scan for performance
    - OFF: scan normally
    """

    def __init__(self, db_path="security_config.db", quarantine_dir="quarantine_zone", manual_game_mode=False):
        super().__init__(quarantine_dir=quarantine_dir)
        self.db_path = db_path
        self.manual_game_mode = manual_game_mode
        self.game_labels = ["league of legends", "diablo", "valorant", "steam"]

    def set_game_mode(self, enabled: bool):
        self.manual_game_mode = bool(enabled)
        return self.game_status()

    def toggle_game_mode(self):
        self.manual_game_mode = not self.manual_game_mode
        return self.game_status()

    def game_status(self):
        if self.manual_game_mode:
            return {
                "running": True,
                "source": "manual_toggle",
                "message": "Manual game mode is ON. Scans will be skipped for performance.",
            }
        return {
            "running": False,
            "source": "manual_toggle",
            "message": "Manual game mode is OFF. Normal scan flow is active.",
        }

    def is_game_running(self):
        return self.game_status()

    def scan_and_quarantine(self, target_folder):
        status = self.game_status()
        if status["running"]:
            return {
                "ok": True,
                "game_mode": True,
                "message": "Game mode is ON. Scan skipped for performance.",
                "game_status": status,
                "quarantined": [],
            }

        result = super().scan_and_quarantine(target_folder)
        result["game_mode"] = False
        result["game_status"] = status
        return result
