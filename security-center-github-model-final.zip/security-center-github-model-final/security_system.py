import sqlite3
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class ScanSummary:
    high_risk: int
    whitelist_count: int
    threat_count: int
    quarantine_count: int


class SecuritySystem:
    def __init__(self, db_path="security_config.db"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.setup_database()

    def setup_database(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT UNIQUE NOT NULL
            )
        """)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS threat_database (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                risk_level TEXT NOT NULL
            )
        """)
        self.conn.commit()
        self.seed_threats()

    def seed_threats(self):
        self.cursor.execute("SELECT COUNT(*) FROM threat_database")
        if self.cursor.fetchone()[0] == 0:
            data = [
                ("Malware", "Trojan.Generic", "High"),
                ("Spyware", "Keylogger.Agent", "Critical"),
                ("Network", "Suspicious Port Scan", "Medium"),
                ("Privacy", "Tracker Cookie", "Low"),
                ("Sandbox", "Virus.Win32.Eicar", "Test"),
            ]
            self.cursor.executemany(
                "INSERT INTO threat_database (type, name, risk_level) VALUES (?, ?, ?)",
                data,
            )
            self.conn.commit()

    def add_whitelist(self, identifier: str):
        identifier = identifier.strip()
        if not identifier:
            return False, "Input required."
        try:
            self.cursor.execute("INSERT INTO whitelist (identifier) VALUES (?)", (identifier,))
            self.conn.commit()
            return True, f"Added: {identifier}"
        except sqlite3.IntegrityError:
            return False, "Already exists."

    def remove_whitelist(self, identifier: str):
        self.cursor.execute("DELETE FROM whitelist WHERE identifier = ?", (identifier.strip(),))
        self.conn.commit()
        return self.cursor.rowcount > 0

    def get_whitelist(self) -> List[str]:
        self.cursor.execute("SELECT identifier FROM whitelist ORDER BY identifier")
        return [row[0] for row in self.cursor.fetchall()]

    def get_threats(self) -> List[Tuple[str, str, str]]:
        self.cursor.execute("SELECT type, name, risk_level FROM threat_database ORDER BY id")
        return self.cursor.fetchall()

    def add_threat(self, threat_type: str, name: str, risk_level: str):
        threat_type = threat_type.strip()
        name = name.strip()
        risk_level = risk_level.strip()
        if not threat_type or not name or not risk_level:
            return False, "Threat type, name, and risk level are required."
        self.cursor.execute(
            "INSERT INTO threat_database (type, name, risk_level) VALUES (?, ?, ?)",
            (threat_type, name, risk_level),
        )
        self.conn.commit()
        return True, f"Threat added: {name}"

    def smart_scan_summary(self, quarantine_count=0) -> ScanSummary:
        threats = self.get_threats()
        high = sum(1 for _, _, risk in threats if risk in ("High", "Critical"))
        return ScanSummary(
            high_risk=high,
            whitelist_count=len(self.get_whitelist()),
            threat_count=len(threats),
            quarantine_count=quarantine_count,
        )
