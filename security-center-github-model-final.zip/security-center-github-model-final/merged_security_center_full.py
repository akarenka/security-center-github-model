import tkinter.messagebox as messagebox
import customtkinter as ctk

from security_system import SecuritySystem
from sandbox_drill import EnhancedSandboxDrill


LANG = {
    "zh": {
        "app": "防護中心",
        "status": "狀態",
        "security": "安全性",
        "privacy": "隱私",
        "performance": "性能",
        "apps": "應用程式",
        "whitelist": "白名單",
        "threat_db": "威脅資料庫",
        "sandbox": "沙盒測試",
        "game_mode": "遊戲模式",
        "game_guard": "遊戲防護",
        "smart_scan": "智能掃描",
        "language": "語言",
        "create_env": "建立測試環境",
        "scan_quarantine": "掃描並隔離",
        "list_quarantine": "瀏覽隔離區",
        "recovery": "系統修復",
        "clean": "清理隔離區",
        "run_all": "Run All Functions",
        "reset": "Reset",
        "toggle_game": "遊戲模式 ON/OFF",
        "score": "分數",
        "level": "等級",
        "combo": "連擊",
        "achievements": "成就",
    },
    "en": {
        "app": "Protection Center",
        "status": "Status",
        "security": "Security",
        "privacy": "Privacy",
        "performance": "Performance",
        "apps": "Applications",
        "whitelist": "Whitelist",
        "threat_db": "Threat Database",
        "sandbox": "Sandbox Drill",
        "game_mode": "Game Mode",
        "game_guard": "Game Guard",
        "smart_scan": "Smart Scan",
        "language": "Language",
        "create_env": "Create Test Environment",
        "scan_quarantine": "Scan & Quarantine",
        "list_quarantine": "List Quarantine",
        "recovery": "System Recovery",
        "clean": "Clean Quarantine",
        "run_all": "Run All Functions",
        "reset": "Reset",
        "toggle_game": "Game Mode ON/OFF",
        "score": "Score",
        "level": "Level",
        "combo": "Combo",
        "achievements": "Achievements",
    },
    "ja": {
        "app": "保護センター",
        "status": "状態",
        "security": "セキュリティ",
        "privacy": "プライバシー",
        "performance": "パフォーマンス",
        "apps": "アプリ",
        "whitelist": "ホワイトリスト",
        "threat_db": "脅威データベース",
        "sandbox": "サンドボックス",
        "game_mode": "ゲームモード",
        "game_guard": "ゲーム保護",
        "smart_scan": "スマートスキャン",
        "language": "言語",
        "create_env": "テスト環境を作成",
        "scan_quarantine": "スキャンして隔離",
        "list_quarantine": "隔離リスト表示",
        "recovery": "システム修復",
        "clean": "隔離を清掃",
        "run_all": "すべて実行",
        "reset": "リセット",
        "toggle_game": "ゲームモード ON/OFF",
        "score": "スコア",
        "level": "レベル",
        "combo": "コンボ",
        "achievements": "実績",
    },
}


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.lang = "zh"
        self.page = "status"
        self.system = SecuritySystem()
        self.drill = EnhancedSandboxDrill()

        self.score = 0
        self.level = 1
        self.combo = 0
        self.achievements = set()

        self.geometry("1200x760")
        self.minsize(1000, 640)
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.brand = ctk.CTkLabel(self.sidebar, font=("Arial", 24, "bold"))
        self.brand.pack(pady=(24, 8))

        self.lang_menu = ctk.CTkOptionMenu(self.sidebar, values=["中文", "English", "日本語"], command=self.change_language)
        self.lang_menu.set("中文")
        self.lang_menu.pack(fill="x", padx=12, pady=(0, 16))

        self.nav = {}
        navs = [
            ("status", self.show_status),
            ("security", self.show_security),
            ("privacy", self.show_privacy),
            ("performance", self.show_performance),
            ("apps", self.show_apps),
            ("whitelist", self.show_whitelist),
            ("threat_db", self.show_threats),
            ("sandbox", self.show_sandbox),
            ("game_guard", self.show_game_guard),
            ("game_mode", self.show_game_mode),
        ]

        for key, cmd in navs:
            btn = ctk.CTkButton(self.sidebar, fg_color="transparent", anchor="w", command=cmd)
            btn.pack(fill="x", padx=12, pady=5)
            self.nav[key] = btn

        self.main = ctk.CTkFrame(self, fg_color="transparent")
        self.main.pack(side="right", fill="both", expand=True, padx=20, pady=20)

        self.apply_language()
        self.show_status()

    def t(self, key):
        return LANG[self.lang].get(key, key)

    def apply_language(self):
        self.title(self.t("app") + " — All Features")
        self.brand.configure(text=self.t("app"))
        for key, btn in self.nav.items():
            btn.configure(text=self.t(key))

    def change_language(self, value):
        self.lang = {"中文": "zh", "English": "en", "日本語": "ja"}.get(value, "zh")
        self.apply_language()
        self.refresh_page()

    def refresh_page(self):
        pages = {
            "status": self.show_status,
            "security": self.show_security,
            "privacy": self.show_privacy,
            "performance": self.show_performance,
            "apps": self.show_apps,
            "whitelist": self.show_whitelist,
            "threat_db": self.show_threats,
            "sandbox": self.show_sandbox,
            "game_guard": self.show_game_guard,
            "game_mode": self.show_game_mode,
        }
        pages.get(self.page, self.show_status)()

    def clear(self):
        for w in self.main.winfo_children():
            w.destroy()

    def title_block(self, title, subtitle=""):
        ctk.CTkLabel(self.main, text=title, font=("Arial", 30, "bold")).pack(anchor="w", pady=(4, 4))
        if subtitle:
            ctk.CTkLabel(self.main, text=subtitle, text_color="#B0B0B0", wraplength=820).pack(anchor="w", pady=(0, 18))

    def output_box(self, height=320):
        box = ctk.CTkTextbox(self.main, height=height)
        box.pack(fill="both", expand=True, pady=12)
        return box

    def write_box(self, box, text):
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", text)
        box.configure(state="disabled")

    def append_box(self, box, text):
        box.configure(state="normal")
        box.insert("end", text + "\n")
        box.see("end")
        box.configure(state="disabled")

    def award(self, points, achievement=None):
        self.score += points
        self.combo += 1
        self.level = 1 + self.score // 100
        if achievement:
            self.achievements.add(achievement)

    def game_toggle_text(self):
        return f"{self.t('toggle_game')}: {'ON' if self.drill.manual_game_mode else 'OFF'}"

    def show_status(self):
        self.page = "status"
        self.clear()
        self.title_block(self.t("status"), "All features: security dashboard, sandbox, manual game mode, i18n, scoring.")

        cards = ctk.CTkFrame(self.main, fg_color="transparent")
        cards.pack(pady=20)

        for label, emoji in [
            (self.t("security"), "🛡️"),
            (self.t("privacy"), "🔒"),
            (self.t("performance"), "🚀"),
            (self.t("sandbox"), "🧪"),
            (self.t("game_mode"), "🎮"),
        ]:
            card = ctk.CTkFrame(cards, width=155, height=145)
            card.pack(side="left", padx=8)
            card.pack_propagate(False)
            ctk.CTkLabel(card, text=emoji, font=("Arial", 38)).pack(pady=(18, 8))
            ctk.CTkLabel(card, text=label, font=("Arial", 15, "bold")).pack()

        ctk.CTkButton(self.main, text=self.t("smart_scan"), width=280, height=48, command=self.smart_scan).pack(anchor="w", pady=8)
        self.status_box = self.output_box(280)
        self.write_box(self.status_box, "Ready.")

    def smart_scan(self):
        q = len(self.drill.list_quarantine())
        summary = self.system.smart_scan_summary(q)
        self.award(10, "First Scan")
        self.write_box(
            self.status_box,
            f"{self.t('smart_scan')}: Done\n\n"
            f"High risk: {summary.high_risk}\n"
            f"{self.t('whitelist')}: {summary.whitelist_count}\n"
            f"{self.t('threat_db')}: {summary.threat_count}\n"
            f"Quarantine: {summary.quarantine_count}\n"
            f"{self.t('game_guard')}: {'ON' if self.drill.manual_game_mode else 'OFF'}\n\n"
            f"{self.t('score')}: {self.score} | {self.t('level')}: {self.level} | {self.t('combo')}: {self.combo}"
        )
        messagebox.showinfo(self.t("smart_scan"), "Done.")

    def show_security(self):
        self.page = "security"
        self.clear()
        self.title_block(self.t("security"), "Shortcut page for whitelist, threats, sandbox, and game guard.")
        for text, cmd in [
            (self.t("whitelist"), self.show_whitelist),
            (self.t("threat_db"), self.show_threats),
            (self.t("sandbox"), self.show_sandbox),
            (self.t("game_guard"), self.show_game_guard),
        ]:
            ctk.CTkButton(self.main, text=text, command=cmd).pack(anchor="w", pady=8)

    def show_privacy(self):
        self.page = "privacy"
        self.clear()
        self.title_block(self.t("privacy"), "Demo privacy module.")
        box = self.output_box()
        self.write_box(box, "Implemented demo checks:\n- Browser permission review\n- Tracker review\n- Cookie review\n- Privacy risk notes")

    def show_performance(self):
        self.page = "performance"
        self.clear()
        self.title_block(self.t("performance"), "Demo performance module.")
        box = self.output_box()
        self.write_box(box, "Implemented demo checks:\n- Startup item review\n- Resource usage notes\n- Temporary file review\n- Game mode performance skip")

    def show_apps(self):
        self.page = "apps"
        self.clear()
        self.title_block(self.t("apps"), "Demo application module.")
        box = self.output_box()
        self.write_box(box, "Implemented demo checks:\n- Application allowlist\n- App risk notes\n- Version review placeholder\n- Permission review placeholder")

    def show_whitelist(self):
        self.page = "whitelist"
        self.clear()
        self.title_block(self.t("whitelist"), "Add, remove, and display trusted identifiers.")

        row = ctk.CTkFrame(self.main)
        row.pack(fill="x", pady=8)
        self.white_entry = ctk.CTkEntry(row, placeholder_text="trusted_app.exe")
        self.white_entry.pack(side="left", fill="x", expand=True, padx=8, pady=8)
        ctk.CTkButton(row, text="+", width=55, command=self.add_white).pack(side="left", padx=5)
        ctk.CTkButton(row, text="-", width=55, command=self.remove_white).pack(side="left", padx=5)

        self.white_box = self.output_box(380)
        self.refresh_white()

    def refresh_white(self):
        items = self.system.get_whitelist()
        self.write_box(self.white_box, "\n".join(items) if items else "Empty.")

    def add_white(self):
        ok, msg = self.system.add_whitelist(self.white_entry.get())
        if ok:
            self.award(15, "Whitelist Keeper")
            self.white_entry.delete(0, "end")
            self.refresh_white()
            messagebox.showinfo("Done", msg)
        else:
            messagebox.showwarning("Notice", msg)

    def remove_white(self):
        value = self.white_entry.get().strip()
        if not value:
            messagebox.showwarning("Notice", "Input required.")
            return
        if self.system.remove_whitelist(value):
            self.award(10)
            self.refresh_white()
            messagebox.showinfo("Done", f"Removed: {value}")
        else:
            messagebox.showwarning("Notice", "Not found.")

    def show_threats(self):
        self.page = "threat_db"
        self.clear()
        self.title_block(self.t("threat_db"), "Display and add demo threat records.")

        row = ctk.CTkFrame(self.main)
        row.pack(fill="x", pady=8)
        self.threat_type = ctk.CTkEntry(row, placeholder_text="Type")
        self.threat_name = ctk.CTkEntry(row, placeholder_text="Name")
        self.threat_risk = ctk.CTkEntry(row, placeholder_text="Risk")
        self.threat_type.pack(side="left", fill="x", expand=True, padx=4)
        self.threat_name.pack(side="left", fill="x", expand=True, padx=4)
        self.threat_risk.pack(side="left", fill="x", expand=True, padx=4)
        ctk.CTkButton(row, text="+", width=55, command=self.add_threat).pack(side="left", padx=4)

        self.threat_box = self.output_box(380)
        self.refresh_threats()

    def refresh_threats(self):
        rows = self.system.get_threats()
        text = "Type | Name | Risk\n" + "-" * 60 + "\n"
        for t, n, r in rows:
            text += f"{t} | {n} | {r}\n"
        self.write_box(self.threat_box, text)

    def add_threat(self):
        ok, msg = self.system.add_threat(self.threat_type.get(), self.threat_name.get(), self.threat_risk.get())
        if ok:
            self.award(15, "Threat Curator")
            self.threat_type.delete(0, "end")
            self.threat_name.delete(0, "end")
            self.threat_risk.delete(0, "end")
            self.refresh_threats()
            messagebox.showinfo("Done", msg)
        else:
            messagebox.showwarning("Notice", msg)

    def show_sandbox(self):
        self.page = "sandbox"
        self.clear()
        self.title_block(self.t("sandbox"), "Create environment, scan, quarantine, list, recover, clean, reset.")

        controls = ctk.CTkFrame(self.main)
        controls.pack(fill="x", pady=8)
        for text, cmd in [
            (self.t("create_env"), self.sandbox_create),
            (self.t("scan_quarantine"), self.sandbox_scan),
            (self.t("list_quarantine"), self.sandbox_list),
            (self.t("recovery"), self.sandbox_recovery),
            (self.t("clean"), self.sandbox_clean),
            (self.t("run_all"), self.sandbox_run_all),
            (self.t("reset"), self.sandbox_reset),
        ]:
            ctk.CTkButton(controls, text=text, width=118, command=cmd).pack(side="left", padx=3, pady=6)

        self.sandbox_box = self.output_box(430)
        self.write_box(self.sandbox_box, "Sandbox ready.")

    def sandbox_create(self):
        files = self.drill.create_test_environment()
        self.award(10, "Lab Builder")
        self.append_box(self.sandbox_box, "=== Create Environment ===")
        for f in files:
            self.append_box(self.sandbox_box, "[Create] " + f)

    def sandbox_scan(self):
        self.append_box(self.sandbox_box, "\n=== Scan & Quarantine ===")
        result = self.drill.scan_and_quarantine("temp_work")
        if result.get("game_mode"):
            self.award(20, "Game Shield")
            self.append_box(self.sandbox_box, "[Game Mode] " + result["message"])
            return
        self.award(30 if result["quarantined"] else 5, "Threat Hunter")
        for item in result["quarantined"]:
            self.append_box(self.sandbox_box, "[Quarantine] " + item)
        self.append_box(self.sandbox_box, result["message"])

    def sandbox_list(self):
        self.award(5)
        self.append_box(self.sandbox_box, "\n=== List Quarantine ===")
        self.append_box(self.sandbox_box, str(self.drill.list_quarantine()))

    def sandbox_recovery(self):
        self.award(20, "System Medic")
        self.append_box(self.sandbox_box, "\n=== Recovery ===")
        result = self.drill.perform_system_recovery()
        for step in result["steps"]:
            self.append_box(self.sandbox_box, "[Recovery] " + step)

    def sandbox_clean(self):
        self.append_box(self.sandbox_box, "\n=== Clean ===")
        result = self.drill.clean_expired_files(days=0)
        self.award(20 if result["removed"] else 5, "Cleanup Crew")
        for item in result["removed"]:
            self.append_box(self.sandbox_box, "[Clean] " + item)
        self.append_box(self.sandbox_box, result["message"])

    def sandbox_reset(self):
        self.drill.reset_demo_environment()
        self.combo = 0
        self.write_box(self.sandbox_box, "Reset complete.")

    def sandbox_run_all(self):
        self.write_box(self.sandbox_box, "=== Run All Functions ===\n")
        self.sandbox_create()
        self.sandbox_scan()
        self.sandbox_list()
        self.sandbox_recovery()
        self.sandbox_clean()
        self.award(50, "Full Clear")
        self.append_box(self.sandbox_box, f"\n{self.t('score')}: {self.score} | {self.t('level')}: {self.level} | {self.t('combo')}: {self.combo}")

    def show_game_guard(self):
        self.page = "game_guard"
        self.clear()
        self.title_block(self.t("game_guard"), "Manual ON/OFF. No psutil, no process scanning.")

        row = ctk.CTkFrame(self.main)
        row.pack(fill="x", pady=8)
        self.game_toggle_btn = ctk.CTkButton(row, text=self.game_toggle_text(), command=self.toggle_game_mode)
        self.game_toggle_btn.pack(side="left", padx=5)
        ctk.CTkButton(row, text=self.t("smart_scan"), command=self.game_guard_scan).pack(side="left", padx=5)

        self.game_guard_box = self.output_box(420)
        self.refresh_game_guard()

    def refresh_game_guard(self):
        status = self.drill.game_status()
        if hasattr(self, "game_toggle_btn"):
            self.game_toggle_btn.configure(text=self.game_toggle_text())
        self.write_box(
            self.game_guard_box,
            f"{self.t('game_guard')}: {'ON' if self.drill.manual_game_mode else 'OFF'}\n"
            f"Source: {status['source']}\n"
            f"Message: {status['message']}\n\n"
            "No psutil.\nNo process scanning.\nManual toggle only."
        )

    def toggle_game_mode(self):
        self.drill.toggle_game_mode()
        self.award(10, "Game Toggle")
        self.refresh_game_guard()

    def game_guard_scan(self):
        self.drill.create_test_environment()
        result = self.drill.scan_and_quarantine("temp_work")
        self.award(20 if result.get("game_mode") else 30, "Game Guard Scan")
        self.write_box(
            self.game_guard_box,
            f"{self.game_toggle_text()}\n\n"
            f"Result: {result['message']}\n"
            f"Game mode skipped: {result.get('game_mode')}\n"
            f"Quarantined: {result['quarantined']}"
        )

    def show_game_mode(self):
        self.page = "game_mode"
        self.clear()
        self.title_block(self.t("game_mode"), "Score, level, combo, and achievements.")

        top = ctk.CTkFrame(self.main)
        top.pack(fill="x", pady=10)
        for label, value in [
            (self.t("score"), self.score),
            (self.t("level"), self.level),
            (self.t("combo"), self.combo),
            (self.t("achievements"), len(self.achievements)),
        ]:
            card = ctk.CTkFrame(top, width=170, height=90)
            card.pack(side="left", padx=8)
            card.pack_propagate(False)
            ctk.CTkLabel(card, text=label, font=("Arial", 15, "bold")).pack(pady=(12, 4))
            ctk.CTkLabel(card, text=str(value), font=("Arial", 26, "bold")).pack()

        box = self.output_box(380)
        ach = "\n".join("🏆 " + x for x in sorted(self.achievements)) or "No achievements yet."
        self.write_box(box, ach + "\n\nGame rules:\nSmart Scan +10\nWhitelist +15\nCreate Env +10\nQuarantine +30\nRecovery +20\nClean +20\nFull Clear +50")


if __name__ == "__main__":
    App().mainloop()
