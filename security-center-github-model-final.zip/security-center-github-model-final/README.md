# Security Center GitHub Model

已完成整理成 **完整 GitHub Model 專案**，並通過基本測試。

📦 下載完整專案 ZIP：  
`security-center-github-model-final.zip`

---

## Overview

Security Center GitHub Model 是一個防禦性安全示範專案，包含桌面 GUI、Canvas 展示版、SQLite 白名單與威脅資料庫、SandboxDrill 沙盒測試、手動遊戲模式與多語言系統。

本版本已 **完全排除 psutil**：

- 無 `import psutil`
- 無 `process_iter`
- 不讀取系統程序清單
- 不自動偵測遊戲程序
- 遊戲模式改為手動 ON/OFF

---

## Features

- 🖥️ CustomTkinter Desktop GUI
- 🌐 Canvas Browser Demo
- 🗃️ SQLite Whitelist
- 🧬 SQLite Threat Database
- 🛡️ Smart Scan
- 🔒 Privacy Page
- 🚀 Performance Page
- 📦 Applications Page
- 🧪 SandboxDrill
- ✅ EICAR test-file creation
- ✅ Scan and quarantine
- ✅ Quarantine list
- ✅ System recovery demo
- ✅ Clean quarantine
- 🎮 Manual Game Mode ON/OFF
- 🎮 Skip scan when Game Mode is ON
- 🌍 中文 / English / 日本語
- 🏆 Score / Level / Combo / Achievements
- ▶️ Run All Functions
- 🔄 Reset

---

## Project Structure

```text
security-center-github-model-final/
├─ README.md
├─ LICENSE
├─ requirements.txt
├─ pyproject.toml
├─ .gitignore
├─ .github/
│  └─ workflows/
│     ├─ ci.yml
│     └─ release.yml
├─ merged_security_center_full.py
├─ canvas_all_features_no_psutil.html
├─ security_system.py
├─ sandbox_drill.py
├─ run_all_tests.py
├─ test_output.txt
└─ verification_no_psutil.txt
```

---

## Install

```bash
pip install -r requirements.txt
```

---

## Run Desktop GUI

```bash
python merged_security_center_full.py
```

---

## Run Tests

```bash
python run_all_tests.py
```

Expected result:

```text
Normal quarantined: 1
Manual game mode skipped: True
PASS
```

---

## Open Canvas Demo

Open this file in your browser:

```text
canvas_all_features_no_psutil.html
```

---

## Manual Game Mode

The project uses one toggle button:

```text
遊戲模式 ON/OFF: OFF
```

Click once:

```text
遊戲模式 ON/OFF: ON
```

When Game Mode is ON, scan is skipped for performance.

---

## Safety Scope

This project is a defensive sandbox demo.

It only creates local demo files and folders:

```text
temp_work/
quarantine_zone/
security_config.db
```

It does not:

- modify OS settings
- delete system files
- attack networks
- exploit devices
- read process lists
- use psutil

---

## Upload to GitHub

```bash
git init
git add .
git commit -m "Initial Security Center GitHub Model"
git branch -M main
git remote add origin https://github.com/akarenka/security-center-github-model.git
git push -u origin main
```

---

## Create Release

```bash
git tag v1.0.0
git push origin v1.0.0
```

GitHub Actions will create a release ZIP when a version tag is pushed.

---

## License

MIT License
