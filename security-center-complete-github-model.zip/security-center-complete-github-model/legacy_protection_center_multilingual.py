import customtkinter as ctk
import sqlite3
import tkinter.messagebox as messagebox
from tkinter import ttk


LANG = {
    "zh": {
        "app_title": "防護中心",
        "status": "狀態",
        "security": "安全性",
        "privacy": "隱私",
        "performance": "性能",
        "apps": "應用程式",
        "whitelist": "白名單",
        "threat_db": "威脅資料庫",
        "language": "語言",
        "status_title": "狀態總覽",
        "status_sub": "查看安全性、隱私與性能狀態。",
        "security_desc": "系統防護與威脅檢查",
        "privacy_desc": "追蹤器與權限檢查",
        "performance_desc": "啟動項目與資源檢查",
        "scan": "智能掃描",
        "scan_hint": "點擊「智能掃描」開始檢查。",
        "scan_done_title": "掃描完成",
        "scan_done_msg": "系統安全性、隱私與性能檢查已完成。",
        "scan_status": "掃描狀態：完成",
        "security_scan": "安全性：發現 {count} 個高風險項目，需要檢查。",
        "privacy_scan": "隱私：隱私檢查完成：建議檢查追蹤器與瀏覽器權限。",
        "performance_scan": "性能：性能檢查完成：建議清理啟動項目。",
        "whitelist_count": "白名單項目：{count}",
        "threat_count": "威脅資料庫項目：{count}",
        "security_title": "安全性",
        "security_sub": "管理威脅偵測與高風險項目。",
        "browse_threats": "瀏覽威脅資料庫",
        "manage_whitelist": "管理白名單",
        "privacy_title": "隱私",
        "privacy_sub": "檢查追蹤器、權限與可疑項目。",
        "privacy_demo": "目前為示範模式：可擴充瀏覽器追蹤器、Cookie、權限檢查。",
        "performance_title": "性能",
        "performance_sub": "檢查啟動項目、資源佔用與系統建議。",
        "performance_demo": "目前為示範模式：可擴充 CPU、RAM、磁碟與啟動程式分析。",
        "apps_title": "應用程式",
        "apps_sub": "管理應用程式允許清單與風險提示。",
        "apps_demo": "目前為示範模式：可擴充應用程式掃描、版本檢查與權限管理。",
        "whitelist_title": "白名單管理",
        "whitelist_sub": "新增或移除允許的檔案、網址、IP 或應用程式名稱。",
        "whitelist_placeholder": "例如：trusted_app.exe 或 192.168.1.10",
        "add": "新增",
        "remove_selected": "移除選取",
        "empty_whitelist": "白名單目前是空的。",
        "enter_whitelist": "請輸入白名單識別名稱。",
        "whitelist_added": "已加入白名單：{item}",
        "whitelist_exists": "此項目已存在於白名單。",
        "remove_input": "請在輸入框填入要移除的白名單項目。",
        "removed": "已移除：{item}",
        "not_found": "找不到此白名單項目。",
        "done": "完成",
        "notice": "注意",
        "threat_title": "威脅資料庫",
        "threat_sub": "查看示範威脅清單與風險等級。",
        "type": "類型",
        "name": "名稱",
        "risk": "風險等級",
    },
    "en": {
        "app_title": "Protection Center",
        "status": "Status",
        "security": "Security",
        "privacy": "Privacy",
        "performance": "Performance",
        "apps": "Applications",
        "whitelist": "Whitelist",
        "threat_db": "Threat Database",
        "language": "Language",
        "status_title": "Status Overview",
        "status_sub": "View security, privacy, and performance status.",
        "security_desc": "System protection and threat checks",
        "privacy_desc": "Tracker and permission checks",
        "performance_desc": "Startup and resource checks",
        "scan": "Smart Scan",
        "scan_hint": "Click “Smart Scan” to start checking.",
        "scan_done_title": "Scan Complete",
        "scan_done_msg": "Security, privacy, and performance checks are complete.",
        "scan_status": "Scan status: Complete",
        "security_scan": "Security: Found {count} high-risk items that need review.",
        "privacy_scan": "Privacy: Check complete. Review trackers and browser permissions.",
        "performance_scan": "Performance: Check complete. Consider cleaning startup items.",
        "whitelist_count": "Whitelist items: {count}",
        "threat_count": "Threat database items: {count}",
        "security_title": "Security",
        "security_sub": "Manage threat detection and high-risk items.",
        "browse_threats": "Browse Threat Database",
        "manage_whitelist": "Manage Whitelist",
        "privacy_title": "Privacy",
        "privacy_sub": "Check trackers, permissions, and suspicious items.",
        "privacy_demo": "Demo mode: expandable to browser trackers, cookies, and permission checks.",
        "performance_title": "Performance",
        "performance_sub": "Check startup items, resource usage, and system suggestions.",
        "performance_demo": "Demo mode: expandable to CPU, RAM, disk, and startup-program analysis.",
        "apps_title": "Applications",
        "apps_sub": "Manage application allowlists and risk notices.",
        "apps_demo": "Demo mode: expandable to app scanning, version checks, and permission management.",
        "whitelist_title": "Whitelist Manager",
        "whitelist_sub": "Add or remove allowed files, URLs, IPs, or app names.",
        "whitelist_placeholder": "Example: trusted_app.exe or 192.168.1.10",
        "add": "Add",
        "remove_selected": "Remove Selected",
        "empty_whitelist": "The whitelist is currently empty.",
        "enter_whitelist": "Please enter a whitelist identifier.",
        "whitelist_added": "Added to whitelist: {item}",
        "whitelist_exists": "This item already exists in the whitelist.",
        "remove_input": "Enter the whitelist item to remove in the input box.",
        "removed": "Removed: {item}",
        "not_found": "Whitelist item not found.",
        "done": "Done",
        "notice": "Notice",
        "threat_title": "Threat Database",
        "threat_sub": "View demo threats and risk levels.",
        "type": "Type",
        "name": "Name",
        "risk": "Risk Level",
    },
    "ja": {
        "app_title": "保護センター",
        "status": "状態",
        "security": "セキュリティ",
        "privacy": "プライバシー",
        "performance": "パフォーマンス",
        "apps": "アプリ",
        "whitelist": "ホワイトリスト",
        "threat_db": "脅威データベース",
        "language": "言語",
        "status_title": "状態の概要",
        "status_sub": "セキュリティ、プライバシー、パフォーマンスの状態を確認します。",
        "security_desc": "システム保護と脅威チェック",
        "privacy_desc": "トラッカーと権限のチェック",
        "performance_desc": "起動項目とリソースのチェック",
        "scan": "スマートスキャン",
        "scan_hint": "「スマートスキャン」をクリックしてチェックを開始します。",
        "scan_done_title": "スキャン完了",
        "scan_done_msg": "セキュリティ、プライバシー、パフォーマンスのチェックが完了しました。",
        "scan_status": "スキャン状態：完了",
        "security_scan": "セキュリティ：確認が必要な高リスク項目が {count} 件見つかりました。",
        "privacy_scan": "プライバシー：チェック完了。トラッカーとブラウザ権限を確認してください。",
        "performance_scan": "パフォーマンス：チェック完了。起動項目の整理を推奨します。",
        "whitelist_count": "ホワイトリスト項目：{count}",
        "threat_count": "脅威データベース項目：{count}",
        "security_title": "セキュリティ",
        "security_sub": "脅威検出と高リスク項目を管理します。",
        "browse_threats": "脅威データベースを見る",
        "manage_whitelist": "ホワイトリスト管理",
        "privacy_title": "プライバシー",
        "privacy_sub": "トラッカー、権限、不審な項目を確認します。",
        "privacy_demo": "デモモード：ブラウザトラッカー、Cookie、権限チェックへ拡張できます。",
        "performance_title": "パフォーマンス",
        "performance_sub": "起動項目、リソース使用量、システム提案を確認します。",
        "performance_demo": "デモモード：CPU、RAM、ディスク、起動プログラム分析へ拡張できます。",
        "apps_title": "アプリ",
        "apps_sub": "アプリの許可リストとリスク通知を管理します。",
        "apps_demo": "デモモード：アプリスキャン、バージョン確認、権限管理へ拡張できます。",
        "whitelist_title": "ホワイトリスト管理",
        "whitelist_sub": "許可するファイル、URL、IP、アプリ名を追加または削除します。",
        "whitelist_placeholder": "例：trusted_app.exe または 192.168.1.10",
        "add": "追加",
        "remove_selected": "選択項目を削除",
        "empty_whitelist": "ホワイトリストは現在空です。",
        "enter_whitelist": "ホワイトリスト識別子を入力してください。",
        "whitelist_added": "ホワイトリストに追加しました：{item}",
        "whitelist_exists": "この項目はすでにホワイトリストに存在します。",
        "remove_input": "削除するホワイトリスト項目を入力してください。",
        "removed": "削除しました：{item}",
        "not_found": "ホワイトリスト項目が見つかりません。",
        "done": "完了",
        "notice": "注意",
        "threat_title": "脅威データベース",
        "threat_sub": "デモ用の脅威一覧とリスクレベルを表示します。",
        "type": "種類",
        "name": "名前",
        "risk": "リスクレベル",
    }
}


class SecuritySystem:
    def __init__(self, db_path="security_config.db"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.setup_database()

    def setup_database(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT UNIQUE NOT NULL
            )
        """)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS threat_database (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                risk_level TEXT NOT NULL
            )
        """)
        self.conn.commit()
        self.seed_threats()

    def seed_threats(self):
        self.cursor.execute("SELECT COUNT(*) FROM threat_database")
        if self.cursor.fetchone()[0] == 0:
            demo_threats = [
                ("Malware", "Trojan.Generic", "High"),
                ("Spyware", "Keylogger.Agent", "Critical"),
                ("Network", "Suspicious Port Scan", "Medium"),
                ("Privacy", "Tracker Cookie", "Low"),
                ("Performance", "Startup Overload", "Medium"),
            ]
            self.cursor.executemany(
                "INSERT INTO threat_database (type, name, risk_level) VALUES (?, ?, ?)",
                demo_threats
            )
            self.conn.commit()

    def add_whitelist(self, identifier):
        identifier = identifier.strip()
        if not identifier:
            return False, "enter_whitelist"
        try:
            self.cursor.execute("INSERT INTO whitelist (identifier) VALUES (?)", (identifier,))
            self.conn.commit()
            return True, identifier
        except sqlite3.IntegrityError:
            return False, "whitelist_exists"

    def remove_whitelist(self, identifier):
        self.cursor.execute("DELETE FROM whitelist WHERE identifier = ?", (identifier,))
        self.conn.commit()
        return self.cursor.rowcount > 0

    def get_whitelist(self):
        self.cursor.execute("SELECT identifier FROM whitelist ORDER BY identifier")
        return [row[0] for row in self.cursor.fetchall()]

    def get_threats(self):
        self.cursor.execute("SELECT type, name, risk_level FROM threat_database ORDER BY risk_level DESC, name")
        return self.cursor.fetchall()

    def run_scan(self):
        whitelist_count = len(self.get_whitelist())
        threats = self.get_threats()
        high_count = sum(1 for _, _, risk in threats if risk in ("High", "Critical"))
        return {
            "high_count": high_count,
            "whitelist_count": whitelist_count,
            "threat_count": len(threats),
        }


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.system = SecuritySystem()
        self.lang_code = "zh"
        self.current_page = "status"

        self.geometry("1020x640")
        self.minsize(920, 570)
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        self.sidebar = ctk.CTkFrame(self, width=190, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.brand_label = ctk.CTkLabel(self.sidebar, font=("Arial", 24, "bold"))
        self.brand_label.pack(pady=(25, 16))

        self.lang_label = ctk.CTkLabel(self.sidebar, anchor="w")
        self.lang_label.pack(fill="x", padx=12, pady=(0, 4))

        self.lang_selector = ctk.CTkOptionMenu(
            self.sidebar,
            values=["中文", "English", "日本語"],
            command=self.change_language
        )
        self.lang_selector.set("中文")
        self.lang_selector.pack(fill="x", padx=12, pady=(0, 18))

        self.nav_buttons = {}
        nav_items = [
            ("status", self.show_status),
            ("security", self.show_security),
            ("privacy", self.show_privacy),
            ("performance", self.show_performance),
            ("apps", self.show_apps),
            ("whitelist", self.open_whitelist),
            ("threat_db", self.browse_threats),
        ]

        for key, command in nav_items:
            btn = ctk.CTkButton(
                self.sidebar,
                fg_color="transparent",
                anchor="w",
                command=command
            )
            btn.pack(fill="x", pady=6, padx=12)
            self.nav_buttons[key] = btn

        self.main_area = ctk.CTkFrame(self, fg_color="transparent")
        self.main_area.pack(side="right", fill="both", expand=True, padx=20, pady=20)

        self.apply_language()
        self.show_status()

    def t(self, key):
        return LANG[self.lang_code][key]

    def apply_language(self):
        self.title(self.t("app_title"))
        self.brand_label.configure(text=self.t("app_title"))
        self.lang_label.configure(text=self.t("language"))
        for key, btn in self.nav_buttons.items():
            btn.configure(text=self.t(key))

    def change_language(self, selected):
        mapping = {"中文": "zh", "English": "en", "日本語": "ja"}
        self.lang_code = mapping.get(selected, "zh")
        self.apply_language()
        self.refresh_current_page()

    def refresh_current_page(self):
        page_map = {
            "status": self.show_status,
            "security": self.show_security,
            "privacy": self.show_privacy,
            "performance": self.show_performance,
            "apps": self.show_apps,
            "whitelist": self.open_whitelist,
            "threat_db": self.browse_threats,
        }
        page_map.get(self.current_page, self.show_status)()

    def clear_main(self):
        for widget in self.main_area.winfo_children():
            widget.destroy()

    def page_title(self, title, subtitle=""):
        ctk.CTkLabel(
            self.main_area,
            text=title,
            font=("Arial", 30, "bold")
        ).pack(anchor="w", pady=(5, 5))
        if subtitle:
            ctk.CTkLabel(
                self.main_area,
                text=subtitle,
                text_color="#B0B0B0",
                font=("Arial", 14)
            ).pack(anchor="w", pady=(0, 20))

    def show_status(self):
        self.current_page = "status"
        self.clear_main()
        self.page_title(self.t("status_title"), self.t("status_sub"))

        icons_frame = ctk.CTkFrame(self.main_area, fg_color="transparent")
        icons_frame.pack(pady=35)

        icon_data = [
            ("security", "🛡️", self.t("security_desc")),
            ("privacy", "🔒", self.t("privacy_desc")),
            ("performance", "🚀", self.t("performance_desc")),
        ]

        for key, emoji, desc in icon_data:
            frame = ctk.CTkFrame(icons_frame, width=205, height=175)
            frame.pack(side="left", padx=14)
            frame.pack_propagate(False)
            ctk.CTkLabel(frame, text=emoji, font=("Arial", 44)).pack(pady=(22, 8))
            ctk.CTkLabel(frame, text=self.t(key), font=("Arial", 18, "bold")).pack()
            ctk.CTkLabel(frame, text=desc, text_color="#B0B0B0", wraplength=170).pack(pady=8)

        self.scan_btn = ctk.CTkButton(
            self.main_area,
            text=self.t("scan"),
            height=54,
            width=330,
            font=("Arial", 18, "bold"),
            command=self.run_scan
        )
        self.scan_btn.pack(pady=25)

        self.scan_result = ctk.CTkTextbox(self.main_area, height=135)
        self.scan_result.pack(fill="x", padx=30, pady=10)
        self.scan_result.insert("1.0", self.t("scan_hint"))
        self.scan_result.configure(state="disabled")

    def run_scan(self):
        result = self.system.run_scan()
        text = (
            f"{self.t('scan_status')}\n\n"
            f"🛡️ {self.t('security_scan').format(count=result['high_count'])}\n"
            f"🔒 {self.t('privacy_scan')}\n"
            f"🚀 {self.t('performance_scan')}\n\n"
            f"{self.t('whitelist_count').format(count=result['whitelist_count'])}\n"
            f"{self.t('threat_count').format(count=result['threat_count'])}"
        )

        self.scan_result.configure(state="normal")
        self.scan_result.delete("1.0", "end")
        self.scan_result.insert("1.0", text)
        self.scan_result.configure(state="disabled")

        messagebox.showinfo(self.t("scan_done_title"), self.t("scan_done_msg"))

    def show_security(self):
        self.current_page = "security"
        self.clear_main()
        self.page_title(self.t("security_title"), self.t("security_sub"))
        ctk.CTkButton(self.main_area, text=self.t("browse_threats"), command=self.browse_threats).pack(anchor="w", pady=10)
        ctk.CTkButton(self.main_area, text=self.t("manage_whitelist"), command=self.open_whitelist).pack(anchor="w", pady=10)

    def show_privacy(self):
        self.current_page = "privacy"
        self.clear_main()
        self.page_title(self.t("privacy_title"), self.t("privacy_sub"))
        ctk.CTkLabel(self.main_area, text=self.t("privacy_demo"), font=("Arial", 16), wraplength=720).pack(anchor="w", pady=15)

    def show_performance(self):
        self.current_page = "performance"
        self.clear_main()
        self.page_title(self.t("performance_title"), self.t("performance_sub"))
        ctk.CTkLabel(self.main_area, text=self.t("performance_demo"), font=("Arial", 16), wraplength=720).pack(anchor="w", pady=15)

    def show_apps(self):
        self.current_page = "apps"
        self.clear_main()
        self.page_title(self.t("apps_title"), self.t("apps_sub"))
        ctk.CTkLabel(self.main_area, text=self.t("apps_demo"), font=("Arial", 16), wraplength=720).pack(anchor="w", pady=15)

    def open_whitelist(self):
        self.current_page = "whitelist"
        self.clear_main()
        self.page_title(self.t("whitelist_title"), self.t("whitelist_sub"))

        input_frame = ctk.CTkFrame(self.main_area)
        input_frame.pack(fill="x", pady=10)

        self.whitelist_entry = ctk.CTkEntry(input_frame, placeholder_text=self.t("whitelist_placeholder"))
        self.whitelist_entry.pack(side="left", fill="x", expand=True, padx=10, pady=10)

        ctk.CTkButton(input_frame, text=self.t("add"), command=self.add_whitelist_item).pack(side="left", padx=10)
        ctk.CTkButton(input_frame, text=self.t("remove_selected"), command=self.remove_whitelist_item).pack(side="left", padx=10)

        self.whitelist_box = ctk.CTkTextbox(self.main_area, height=320)
        self.whitelist_box.pack(fill="both", expand=True, pady=15)
        self.refresh_whitelist()

    def add_whitelist_item(self):
        identifier = self.whitelist_entry.get()
        success, result = self.system.add_whitelist(identifier)
        if success:
            self.whitelist_entry.delete(0, "end")
            self.refresh_whitelist()
            messagebox.showinfo(self.t("done"), self.t("whitelist_added").format(item=result))
        else:
            messagebox.showwarning(self.t("notice"), self.t(result))

    def remove_whitelist_item(self):
        identifier = self.whitelist_entry.get().strip()
        if not identifier:
            messagebox.showwarning(self.t("notice"), self.t("remove_input"))
            return
        removed = self.system.remove_whitelist(identifier)
        self.refresh_whitelist()
        if removed:
            messagebox.showinfo(self.t("done"), self.t("removed").format(item=identifier))
        else:
            messagebox.showwarning(self.t("notice"), self.t("not_found"))

    def refresh_whitelist(self):
        items = self.system.get_whitelist()
        self.whitelist_box.configure(state="normal")
        self.whitelist_box.delete("1.0", "end")
        if items:
            self.whitelist_box.insert("1.0", "\n".join(items))
        else:
            self.whitelist_box.insert("1.0", self.t("empty_whitelist"))
        self.whitelist_box.configure(state="disabled")

    def browse_threats(self):
        self.current_page = "threat_db"
        self.clear_main()
        self.page_title(self.t("threat_title"), self.t("threat_sub"))

        table_frame = ctk.CTkFrame(self.main_area)
        table_frame.pack(fill="both", expand=True, pady=10)

        columns = ("type", "name", "risk")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        tree.heading("type", text=self.t("type"))
        tree.heading("name", text=self.t("name"))
        tree.heading("risk", text=self.t("risk"))
        tree.column("type", width=160)
        tree.column("name", width=320)
        tree.column("risk", width=120)

        for threat_type, name, risk in self.system.get_threats():
            tree.insert("", "end", values=(threat_type, name, risk))

        tree.pack(fill="both", expand=True, padx=10, pady=10)


if __name__ == "__main__":
    app = App()
    app.mainloop()
