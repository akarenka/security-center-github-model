from security_center.core import SecuritySystem


def test_whitelist_add_remove(tmp_path):
    db = tmp_path / "test.db"
    system = SecuritySystem(str(db))
    assert system.add_whitelist("trusted_app.exe") is True
    assert "trusted_app.exe" in system.get_whitelist()
    assert system.remove_whitelist("trusted_app.exe") is True


def test_scan_result(tmp_path):
    db = tmp_path / "test.db"
    suspicious = tmp_path / "demo.bat"
    suspicious.write_text("echo demo", encoding="utf-8")
    system = SecuritySystem(str(db))
    result = system.run_scan(tmp_path)
    assert result.status == "complete"
    assert result.file_count >= 1
    assert result.suspicious_files >= 1
