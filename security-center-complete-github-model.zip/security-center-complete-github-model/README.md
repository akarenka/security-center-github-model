# Security Center GitHub Model

A complete multilingual defensive Security Center project.

## Languages

- 中文
- English
- 日本語

## Included Modules

- Desktop GUI: `apps/desktop_app.py`
- Web Dashboard: `apps/web/index.html`
- REST API: `security_center/api.py`
- Core Engine: `security_center/core.py`
- i18n Language System: `security_center/i18n.py` and `i18n/*.json`
- SQLite storage
- Docker support
- GitHub Actions CI/CD
- Pytest tests

## Safety Scope

This is a defensive demo project. The scan feature is intentionally safe:
it counts files and flags simple demo indicators such as suspicious file extensions.
It does not modify, delete, quarantine, exploit, or attack any system.

## Install

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

macOS/Linux:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run Desktop GUI

```bash
python apps/desktop_app.py
```

## Run API

```bash
uvicorn security_center.api:app --reload
```

API docs:

```text
http://127.0.0.1:8000/docs
```

## Run Web Dashboard

Start the API first, then serve the web folder:

```bash
python -m http.server 5173 -d apps/web
```

Open:

```text
http://127.0.0.1:5173
```

## Docker

```bash
docker compose up --build
```

## API Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/i18n/{lang}` | Language text |
| GET | `/api/whitelist` | List whitelist |
| POST | `/api/whitelist` | Add whitelist item |
| DELETE | `/api/whitelist/{identifier}` | Remove whitelist item |
| GET | `/api/threats` | List demo threats |
| POST | `/api/threats` | Add demo threat |
| POST | `/api/scan` | Run safe defensive scan summary |

## GitHub Upload

```bash
git init
git add .
git commit -m "Initial Security Center GitHub Model"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/security-center-github-model.git
git push -u origin main
```

## License

MIT
