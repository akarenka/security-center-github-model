from __future__ import annotations

from dataclasses import asdict
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .core import SecuritySystem, Threat, scan_to_dict, threat_to_dict
from .i18n import translate

app = FastAPI(
    title="Security Center API",
    description="Defensive multilingual security dashboard demo API.",
    version="1.0.0",
)

system = SecuritySystem()


class WhitelistRequest(BaseModel):
    identifier: str = Field(..., min_length=1, examples=["trusted_app.exe"])


class ThreatRequest(BaseModel):
    type: str = Field(..., examples=["Malware"])
    name: str = Field(..., examples=["Demo.Signature"])
    risk_level: str = Field(..., examples=["Medium"])
    description: str = ""


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "security-center"}


@app.get("/api/i18n/{lang}")
def get_language(lang: str):
    return translate(lang)


@app.get("/api/whitelist")
def list_whitelist():
    return {"items": system.get_whitelist()}


@app.post("/api/whitelist")
def add_whitelist(payload: WhitelistRequest):
    try:
        created = system.add_whitelist(payload.identifier)
        return {"created": created, "identifier": payload.identifier}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.delete("/api/whitelist/{identifier}")
def delete_whitelist(identifier: str):
    removed = system.remove_whitelist(identifier)
    return {"removed": removed, "identifier": identifier}


@app.get("/api/threats")
def list_threats():
    return {"items": [threat_to_dict(t) for t in system.get_threats()]}


@app.post("/api/threats")
def create_threat(payload: ThreatRequest):
    threat = Threat(id=None, **payload.model_dump())
    new_id = system.add_threat(threat)
    return {"id": new_id, **payload.model_dump()}


@app.post("/api/scan")
def run_scan(path: str = "."):
    return scan_to_dict(system.run_scan(path))
