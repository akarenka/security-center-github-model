LANGUAGES = {
    "zh": {
        "app_title": "防護中心",
        "status": "狀態",
        "security": "安全性",
        "privacy": "隱私",
        "performance": "性能",
        "apps": "應用程式",
        "whitelist": "白名單",
        "threat_db": "威脅資料庫",
        "scan": "智能掃描",
        "scan_complete": "掃描完成",
    },
    "en": {
        "app_title": "Protection Center",
        "status": "Status",
        "security": "Security",
        "privacy": "Privacy",
        "performance": "Performance",
        "apps": "Applications",
        "whitelist": "Whitelist",
        "threat_db": "Threat Database",
        "scan": "Smart Scan",
        "scan_complete": "Scan Complete",
    },
    "ja": {
        "app_title": "保護センター",
        "status": "状態",
        "security": "セキュリティ",
        "privacy": "プライバシー",
        "performance": "パフォーマンス",
        "apps": "アプリ",
        "whitelist": "ホワイトリスト",
        "threat_db": "脅威データベース",
        "scan": "スマートスキャン",
        "scan_complete": "スキャン完了",
    },
}


def translate(lang: str) -> dict:
    return LANGUAGES.get(lang, LANGUAGES["zh"])
