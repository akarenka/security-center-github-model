from __future__ import annotations

import hashlib
import os
import sqlite3
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, List, Optional


@dataclass
class Threat:
    id: Optional[int]
    type: str
    name: str
    risk_level: str
    description: str = ""


@dataclass
class ScanResult:
    status: str
    high_risk_count: int
    whitelist_count: int
    threat_count: int
    checked_path: str = ""
    file_count: int = 0
    suspicious_files: int = 0
    message: str = ""


class SecuritySystem:
    """Small defensive demo engine for whitelist, threat database, and safe local scan summaries.

    This project intentionally avoids destructive or offensive actions. The scan function only
    counts files and flags simple demo indicators such as suspicious extensions.
    """

    def __init__(self, db_path: str = "security_config.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.setup_database()

    def setup_database(self) -> None:
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT UNIQUE NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS threat_database (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                description TEXT DEFAULT ''
            )
        """)
        self.conn.commit()
        self.seed_threats()

    def seed_threats(self) -> None:
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) AS c FROM threat_database")
        if cur.fetchone()["c"] == 0:
            demo_threats = [
                ("Malware", "Trojan.Generic", "High", "Demo signature for suspicious generic trojan behavior."),
                ("Spyware", "Keylogger.Agent", "Critical", "Demo signature for possible keylogging behavior."),
                ("Network", "Suspicious Port Scan", "Medium", "Demo network reconnaissance indicator."),
                ("Privacy", "Tracker Cookie", "Low", "Demo browser tracking indicator."),
                ("Performance", "Startup Overload", "Medium", "Demo excessive startup applications indicator."),
            ]
            cur.executemany(
                "INSERT INTO threat_database (type, name, risk_level, description) VALUES (?, ?, ?, ?)",
                demo_threats,
            )
            self.conn.commit()

    def add_whitelist(self, identifier: str) -> bool:
        identifier = identifier.strip()
        if not identifier:
            raise ValueError("Identifier is required")
        try:
            self.conn.execute("INSERT INTO whitelist (identifier) VALUES (?)", (identifier,))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def remove_whitelist(self, identifier: str) -> bool:
        cur = self.conn.execute("DELETE FROM whitelist WHERE identifier = ?", (identifier.strip(),))
        self.conn.commit()
        return cur.rowcount > 0

    def get_whitelist(self) -> List[str]:
        cur = self.conn.execute("SELECT identifier FROM whitelist ORDER BY identifier")
        return [row["identifier"] for row in cur.fetchall()]

    def get_threats(self) -> List[Threat]:
        cur = self.conn.execute(
            "SELECT id, type, name, risk_level, description FROM threat_database ORDER BY id"
        )
        return [Threat(**dict(row)) for row in cur.fetchall()]

    def add_threat(self, threat: Threat) -> int:
        cur = self.conn.execute(
            "INSERT INTO threat_database (type, name, risk_level, description) VALUES (?, ?, ?, ?)",
            (threat.type, threat.name, threat.risk_level, threat.description),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def file_sha256(self, path: str | Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def run_scan(self, path: str | Path = ".") -> ScanResult:
        root = Path(path).expanduser()
        threats = self.get_threats()
        high_count = sum(1 for t in threats if t.risk_level in {"High", "Critical"})
        whitelist_count = len(self.get_whitelist())

        file_count = 0
        suspicious = 0
        suspicious_extensions = {".scr", ".pif", ".bat", ".cmd", ".vbs", ".ps1"}

        if root.exists():
            if root.is_file():
                file_count = 1
                suspicious = 1 if root.suffix.lower() in suspicious_extensions else 0
            else:
                for current, dirs, files in os.walk(root):
                    dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "node_modules", ".venv", "venv"}]
                    for name in files:
                        file_count += 1
                        if Path(name).suffix.lower() in suspicious_extensions:
                            suspicious += 1

        return ScanResult(
            status="complete",
            high_risk_count=high_count,
            whitelist_count=whitelist_count,
            threat_count=len(threats),
            checked_path=str(root),
            file_count=file_count,
            suspicious_files=suspicious,
            message="Defensive demo scan completed. No files were modified.",
        )


def threat_to_dict(threat: Threat) -> dict:
    return asdict(threat)


def scan_to_dict(result: ScanResult) -> dict:
    return asdict(result)
