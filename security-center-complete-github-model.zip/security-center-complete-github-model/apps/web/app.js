const I18N = {
  zh: { title: "防護中心", dashboard: "狀態總覽", scan: "智能掃描", whitelist: "白名單", threats: "威脅資料庫", api: "API 連線", security: "安全性", privacy: "隱私", performance: "性能" },
  en: { title: "Protection Center", dashboard: "Status Overview", scan: "Smart Scan", whitelist: "Whitelist", threats: "Threat Database", api: "API Connection", security: "Security", privacy: "Privacy", performance: "Performance" },
  ja: { title: "保護センター", dashboard: "状態の概要", scan: "スマートスキャン", whitelist: "ホワイトリスト", threats: "脅威データベース", api: "API 接続", security: "セキュリティ", privacy: "プライバシー", performance: "パフォーマンス" }
};

let lang = localStorage.getItem("sc_lang") || "zh";
let page = "dashboard";

const content = document.querySelector("#content");
const langSelect = document.querySelector("#lang");
langSelect.value = lang;

function t(k) { return I18N[lang][k] || k; }

function setLang(value) {
  lang = value;
  localStorage.setItem("sc_lang", lang);
  document.querySelector("#brand").textContent = t("title");
  render();
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}

function dashboard() {
  content.innerHTML = `
    <h2>${t("dashboard")}</h2>
    <p class="muted">Security / Privacy / Performance dashboard</p>
    <div class="grid">
      <div class="card"><div class="emoji">🛡️</div><h3>${t("security")}</h3><p class="muted">Threat review</p></div>
      <div class="card"><div class="emoji">🔒</div><h3>${t("privacy")}</h3><p class="muted">Permission review</p></div>
      <div class="card"><div class="emoji">🚀</div><h3>${t("performance")}</h3><p class="muted">Resource review</p></div>
    </div>
    <button class="primary" id="scan">${t("scan")}</button>
    <div class="panel"><pre id="result">Ready.</pre></div>
  `;
  document.querySelector("#scan").onclick = async () => {
    try {
      const result = await api("/api/scan", { method: "POST" });
      document.querySelector("#result").textContent = JSON.stringify(result, null, 2);
    } catch {
      document.querySelector("#result").textContent = "API not running. Start with: uvicorn security_center.api:app --reload";
    }
  };
}

async function whitelist() {
  content.innerHTML = `
    <h2>${t("whitelist")}</h2>
    <input id="whiteInput" placeholder="trusted_app.exe">
    <button class="primary" id="addWhite">Add</button>
    <div class="panel"><pre id="whiteList">Loading...</pre></div>
  `;
  async function load() {
    try {
      const data = await api("/api/whitelist");
      document.querySelector("#whiteList").textContent = data.items.join("\\n") || "Empty";
    } catch {
      document.querySelector("#whiteList").textContent = "API not running.";
    }
  }
  document.querySelector("#addWhite").onclick = async () => {
    const identifier = document.querySelector("#whiteInput").value.trim();
    if (!identifier) return;
    await api("/api/whitelist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifier })
    });
    await load();
  };
  await load();
}

async function threats() {
  content.innerHTML = `<h2>${t("threats")}</h2><div id="table"></div>`;
  try {
    const data = await api("/api/threats");
    document.querySelector("#table").innerHTML = `
      <table><thead><tr><th>Type</th><th>Name</th><th>Risk</th></tr></thead>
      <tbody>${data.items.map(x => `<tr><td>${x.type}</td><td>${x.name}</td><td>${x.risk_level}</td></tr>`).join("")}</tbody></table>`;
  } catch {
    document.querySelector("#table").innerHTML = `<div class="panel">API not running.</div>`;
  }
}

function apiPage() {
  content.innerHTML = `
    <h2>${t("api")}</h2>
    <div class="panel">
      <p>Run API:</p>
      <pre>uvicorn security_center.api:app --reload</pre>
      <p>Open docs:</p>
      <pre>http://127.0.0.1:8000/docs</pre>
    </div>
  `;
}

function render() {
  document.querySelector("#brand").textContent = t("title");
  ({ dashboard, whitelist, threats, api: apiPage }[page] || dashboard)();
}

document.querySelectorAll("[data-page]").forEach(btn => {
  btn.onclick = () => {
    page = btn.dataset.page;
    render();
  };
});

langSelect.onchange = e => setLang(e.target.value);
render();
