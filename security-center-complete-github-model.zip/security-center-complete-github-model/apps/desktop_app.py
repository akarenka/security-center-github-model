from __future__ import annotations

import customtkinter as ctk
import tkinter.messagebox as messagebox
from tkinter import ttk

from security_center.core import SecuritySystem
from security_center.i18n import LANGUAGES


class DesktopApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.system = SecuritySystem()
        self.lang = "zh"
        self.current_page = "status"

        self.geometry("1020x640")
        self.minsize(920, 570)
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        self.sidebar = ctk.CTkFrame(self, width=190, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.brand = ctk.CTkLabel(self.sidebar, font=("Arial", 24, "bold"))
        self.brand.pack(pady=(25, 16))

        self.lang_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=["中文", "English", "日本語"],
            command=self.change_language,
        )
        self.lang_menu.set("中文")
        self.lang_menu.pack(fill="x", padx=12, pady=(0, 18))

        self.buttons = {}
        for key, command in [
            ("status", self.show_status),
            ("security", self.show_security),
            ("privacy", self.show_privacy),
            ("performance", self.show_performance),
            ("apps", self.show_apps),
            ("whitelist", self.show_whitelist),
            ("threat_db", self.show_threats),
        ]:
            btn = ctk.CTkButton(self.sidebar, fg_color="transparent", anchor="w", command=command)
            btn.pack(fill="x", pady=6, padx=12)
            self.buttons[key] = btn

        self.main = ctk.CTkFrame(self, fg_color="transparent")
        self.main.pack(side="right", fill="both", expand=True, padx=20, pady=20)

        self.apply_language()
        self.show_status()

    def t(self, key):
        return LANGUAGES[self.lang].get(key, key)

    def apply_language(self):
        self.title(self.t("app_title"))
        self.brand.configure(text=self.t("app_title"))
        for key, btn in self.buttons.items():
            btn.configure(text=self.t(key))

    def change_language(self, selected):
        self.lang = {"中文": "zh", "English": "en", "日本語": "ja"}.get(selected, "zh")
        self.apply_language()
        self.refresh()

    def refresh(self):
        {
            "status": self.show_status,
            "security": self.show_security,
            "privacy": self.show_privacy,
            "performance": self.show_performance,
            "apps": self.show_apps,
            "whitelist": self.show_whitelist,
            "threat_db": self.show_threats,
        }.get(self.current_page, self.show_status)()

    def clear(self):
        for widget in self.main.winfo_children():
            widget.destroy()

    def heading(self, title, subtitle=""):
        ctk.CTkLabel(self.main, text=title, font=("Arial", 30, "bold")).pack(anchor="w", pady=(5, 5))
        if subtitle:
            ctk.CTkLabel(self.main, text=subtitle, text_color="#B0B0B0").pack(anchor="w", pady=(0, 20))

    def show_status(self):
        self.current_page = "status"
        self.clear()
        self.heading(self.t("app_title"), "Security / Privacy / Performance")
        cards = ctk.CTkFrame(self.main, fg_color="transparent")
        cards.pack(pady=35)
        for label, emoji in [(self.t("security"), "🛡️"), (self.t("privacy"), "🔒"), (self.t("performance"), "🚀")]:
            card = ctk.CTkFrame(cards, width=205, height=160)
            card.pack(side="left", padx=14)
            card.pack_propagate(False)
            ctk.CTkLabel(card, text=emoji, font=("Arial", 44)).pack(pady=(22, 8))
            ctk.CTkLabel(card, text=label, font=("Arial", 18, "bold")).pack()

        ctk.CTkButton(self.main, text=self.t("scan"), height=54, width=330, font=("Arial", 18, "bold"), command=self.run_scan).pack(pady=25)
        self.output = ctk.CTkTextbox(self.main, height=145)
        self.output.pack(fill="x", padx=30, pady=10)
        self.output.insert("1.0", "Ready.")
        self.output.configure(state="disabled")

    def run_scan(self):
        r = self.system.run_scan(".")
        text = (
            f"{self.t('scan_complete')}\n\n"
            f"High risk items: {r.high_risk_count}\n"
            f"Whitelist items: {r.whitelist_count}\n"
            f"Threat database items: {r.threat_count}\n"
            f"Checked files: {r.file_count}\n"
            f"Suspicious demo indicators: {r.suspicious_files}\n\n"
            f"{r.message}"
        )
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)
        self.output.configure(state="disabled")
        messagebox.showinfo(self.t("scan_complete"), r.message)

    def show_security(self):
        self.current_page = "security"
        self.clear()
        self.heading(self.t("security"), "Threat detection and defensive review.")
        ctk.CTkButton(self.main, text=self.t("threat_db"), command=self.show_threats).pack(anchor="w", pady=8)
        ctk.CTkButton(self.main, text=self.t("whitelist"), command=self.show_whitelist).pack(anchor="w", pady=8)

    def show_privacy(self):
        self.current_page = "privacy"
        self.clear()
        self.heading(self.t("privacy"), "Demo privacy permission panel.")

    def show_performance(self):
        self.current_page = "performance"
        self.clear()
        self.heading(self.t("performance"), "Demo startup and resource panel.")

    def show_apps(self):
        self.current_page = "apps"
        self.clear()
        self.heading(self.t("apps"), "Demo app risk panel.")

    def show_whitelist(self):
        self.current_page = "whitelist"
        self.clear()
        self.heading(self.t("whitelist"), "Add or remove allowed identifiers.")
        row = ctk.CTkFrame(self.main)
        row.pack(fill="x", pady=10)
        self.entry = ctk.CTkEntry(row, placeholder_text="trusted_app.exe")
        self.entry.pack(side="left", fill="x", expand=True, padx=10, pady=10)
        ctk.CTkButton(row, text="+", width=60, command=self.add_white).pack(side="left", padx=6)
        ctk.CTkButton(row, text="-", width=60, command=self.remove_white).pack(side="left", padx=6)
        self.white_box = ctk.CTkTextbox(self.main)
        self.white_box.pack(fill="both", expand=True, pady=12)
        self.refresh_whitelist()

    def refresh_whitelist(self):
        self.white_box.configure(state="normal")
        self.white_box.delete("1.0", "end")
        items = self.system.get_whitelist()
        self.white_box.insert("1.0", "\\n".join(items) if items else "Empty")
        self.white_box.configure(state="disabled")

    def add_white(self):
        value = self.entry.get().strip()
        if not value:
            messagebox.showwarning("Notice", "Identifier required.")
            return
        self.system.add_whitelist(value)
        self.entry.delete(0, "end")
        self.refresh_whitelist()

    def remove_white(self):
        value = self.entry.get().strip()
        self.system.remove_whitelist(value)
        self.refresh_whitelist()

    def show_threats(self):
        self.current_page = "threat_db"
        self.clear()
        self.heading(self.t("threat_db"), "Demo threat intelligence database.")
        tree = ttk.Treeview(self.main, columns=("type", "name", "risk"), show="headings")
        for col in ("type", "name", "risk"):
            tree.heading(col, text=col.title())
        for threat in self.system.get_threats():
            tree.insert("", "end", values=(threat.type, threat.name, threat.risk_level))
        tree.pack(fill="both", expand=True)


if __name__ == "__main__":
    DesktopApp().mainloop()
