#!/usr/bin/env bash
set -e
python apps/desktop_app.py
