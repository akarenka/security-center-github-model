#!/usr/bin/env bash
set -e
uvicorn security_center.api:app --reload
