# Security Center GitHub Model — All Functions Final

完整 **GitHub Model 全功能實裝版**。

本版本整合：

- Python CustomTkinter GUI
- Canvas Browser Demo
- SQLite 白名單
- SQLite 威脅資料庫
- SandboxDrill 沙盒掃描
- 隔離區管理
- 防呆確認機制
- 手動遊戲模式
- 多語言 UI
- GitHub Actions CI
- Release ZIP workflow

---

## Safety Policy

本專案是防禦性安全示範，只操作本地 demo 資料夾：

```text
temp_work/
quarantine_zone/
restored_files/
security_config.db
```

不會：

- 修改系統設定
- 刪除系統檔案
- 攻擊網路
- 讀取系統程序清單
- 使用 psutil
- 使用 process_iter

---

## Features Implemented

### Desktop GUI

- 狀態頁面
- 安全性頁面
- 隱私頁面
- 性能頁面
- 應用程式頁面
- 白名單頁面
- 威脅資料庫頁面
- 沙盒測試頁面
- 隔離區管理視窗
- 遊戲防護頁面
- 遊戲模式頁面
- 中文 / English / 日本語
- 分數 / 等級 / 連擊 / 成就

### Canvas Demo

- 智能掃描
- 白名單管理
- 手動新增白名單
- 手動消除白名單
- 威脅資料庫展示
- 遊戲模式 ON/OFF
- 建立測試環境
- 掃描並隔離
- 瀏覽隔離區
- 隔離區管理彈窗
- 還原確認
- 刪除確認
- 系統修復
- Run All Functions
- Reset

### Whitelist

已保留：

- 手動新增白名單
- 手動消除白名單
- 重新整理白名單
- 顯示白名單總數
- SQLite 永久保存

已移除：

- 清空白名單功能
- Canvas 清空白名單按鈕
- Python GUI 清空白名單按鈕

### Quarantine Manager

`open_quarantine_manager(self)` 已實裝：

```python
def open_quarantine_manager(self):
    """開啟隔離區管理介面"""
    top = ctk.CTkToplevel(self)
    top.title("隔離區管理")
    top.geometry("500x400")

    ctk.CTkLabel(top, text="隔離中的威脅檔案:", font=("Arial", 16)).pack(pady=10)
```

並保留：

- `CTkScrollableFrame`
- 隔離檔案清單
- 每個檔案「刪除」
- 每個檔案「還原」
- 還原到 `restored_files/`

### 防呆確認機制

刪除隔離檔案：

```python
messagebox.askyesno("防呆確認：刪除隔離檔案", confirm_text)
```

還原隔離檔案：

```python
messagebox.askyesno("防呆確認：還原隔離檔案", confirm_text)
```

用途：

- 防止誤觸還原潛在惡意程式
- 防止誤觸刪除重要隔離紀錄

### Run All Functions Safety

`Run All Functions` 會執行：

- 智能掃描
- 白名單展示
- 威脅資料庫展示
- 建立測試環境
- 掃描並隔離
- 瀏覽隔離區
- 系統修復

但不會：

- 刪除隔離區檔案
- 還原隔離區檔案
- 呼叫清理隔離區

---

## Install

```bash
pip install -r requirements.txt
```

---

## Run Desktop GUI

```bash
python merged_security_center_full.py
```

---

## Open Canvas Demo

```text
canvas_all_features_no_psutil.html
```

---

## Run Tests

```bash
python run_all_tests.py
```

Expected:

```text
Manual whitelist remove: True
Duplicate whitelist blocked: True
Normal quarantined: 1
Restore ok: True
Delete ok: True
Run All kept quarantine: True
Run All did not restore: True
Manual game mode skipped: True
Reset ok: True
PASS
```

---

## GitHub Upload

```bash
git init
git add .
git commit -m "Security Center all functions final"
git branch -M main
git remote add origin https://github.com/akarenka/security-center-github-model.git
git push -u origin main
```

---

## Release

```bash
git tag v1.3.0
git push origin v1.3.0
```

GitHub Actions will build a release ZIP.
