import os
import shutil
import tempfile

from security_system import SecuritySystem
from sandbox_drill import EnhancedSandboxDrill


def clean():
    for folder in ["temp_work", "quarantine_zone", "restored_files"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)


def run_all_safe_simulation(drill):
    drill.create_test_environment("temp_work")
    result = drill.scan_and_quarantine("temp_work")
    before = drill.list_quarantine()
    recovery = drill.perform_system_recovery()
    after = drill.list_quarantine()
    return result, before, after, recovery


def run_all_tests():
    print("=== Final All Functions Test ===")
    clean()

    print("\n[1] SQLite whitelist manual add/remove")
    db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    db.close()
    system = SecuritySystem(db.name)
    ok, msg = system.add_whitelist("trusted_app.exe")
    print("[Whitelist Add]", ok, msg)
    duplicate_ok, duplicate_msg = system.add_whitelist("trusted_app.exe")
    print("[Whitelist Duplicate]", duplicate_ok, duplicate_msg)
    removed = system.remove_whitelist("trusted_app.exe")
    print("[Whitelist Remove]", removed)
    print("[Whitelist Final]", system.get_whitelist())

    print("\n[2] Threat DB and smart scan")
    ok, msg = system.add_threat("Demo", "Demo.Threat", "Low")
    summary = system.smart_scan_summary(quarantine_count=0)
    print("[Threat Add]", ok, msg)
    print("[Threat Count]", summary.threat_count)
    print("[High Risk Count]", summary.high_risk)

    print("\n[3] Sandbox create + scan + quarantine")
    drill = EnhancedSandboxDrill(manual_game_mode=False)
    created = drill.create_test_environment("temp_work")
    result = drill.scan_and_quarantine("temp_work")
    q_items = drill.list_quarantine()
    print("[Created]", created)
    print("[Scan]", result["message"])
    print("[Quarantine]", q_items)

    print("\n[4] Quarantine manager restore")
    restore_result = drill.restore_file(q_items[0])
    print("[Restore]", restore_result["ok"], restore_result["message"])
    print("[Restored Exists]", os.path.exists(restore_result["restored"]))
    print("[Quarantine After Restore]", drill.list_quarantine())

    print("\n[5] Quarantine manager delete")
    clean()
    drill = EnhancedSandboxDrill(manual_game_mode=False)
    drill.create_test_environment("temp_work")
    scan2 = drill.scan_and_quarantine("temp_work")
    q_items2 = drill.list_quarantine()
    delete_result = drill.delete_quarantine_file(q_items2[0])
    print("[Delete]", delete_result["ok"], delete_result["message"])
    print("[Quarantine After Delete]", drill.list_quarantine())

    print("\n[6] Run All safe behavior: no delete and no restore")
    clean()
    safe_drill = EnhancedSandboxDrill(manual_game_mode=False)
    run_all_result, before, after, recovery = run_all_safe_simulation(safe_drill)
    restored_exists = os.path.exists("restored_files")
    print("[Run All Scan]", run_all_result["message"])
    print("[Run All Quarantine Before]", before)
    print("[Run All Quarantine After]", after)
    print("[Run All Restored Folder Exists]", restored_exists)
    print("[Recovery Steps]", len(recovery["steps"]))

    print("\n[7] Manual game mode ON skips scan")
    clean()
    game_drill = EnhancedSandboxDrill(manual_game_mode=True)
    game_drill.create_test_environment("temp_work")
    game_result = game_drill.scan_and_quarantine("temp_work")
    print("[Game Scan]", game_result["message"])
    print("[Game Mode]", game_result["game_mode"])
    print("[Game Quarantine]", game_drill.list_quarantine())

    print("\n[8] Reset demo environment")
    reset_ok = game_drill.reset_demo_environment()
    print("[Reset]", reset_ok)
    print("[Quarantine Exists]", os.path.exists("quarantine_zone"))

    print("\n=== Result ===")
    print("Manual whitelist remove:", removed)
    print("Duplicate whitelist blocked:", not duplicate_ok)
    print("Normal quarantined:", len(result["quarantined"]))
    print("Restore ok:", restore_result["ok"])
    print("Delete ok:", delete_result["ok"])
    print("Run All kept quarantine:", before == after and len(after) == 1)
    print("Run All did not restore:", not restored_exists)
    print("Manual game mode skipped:", game_result["game_mode"])
    print("Reset ok:", reset_ok)
    print("PASS")


if __name__ == "__main__":
    run_all_tests()
