#!/usr/bin/env bash
set -e
python merged_security_center_full.py
