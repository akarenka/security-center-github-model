#!/usr/bin/env bash
set -e
python run_all_tests.py
