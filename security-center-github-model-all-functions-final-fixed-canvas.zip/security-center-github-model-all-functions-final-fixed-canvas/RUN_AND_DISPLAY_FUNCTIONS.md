
# Security Center — Run & Display Functions

## Canvas Demo

Open:

canvas_all_features_no_psutil.html

## Functions Displayed

### Main Dashboard

- 狀態頁面
- 智能掃描
- 安全性頁面
- 隱私頁面
- 性能頁面
- 應用程式頁面

### Whitelist

- 手動新增白名單
- 手動消除白名單
- 重複白名單防呆
- SQLite 永久保存
- 已移除清空白名單功能

### Threat Database

- 顯示威脅資料庫
- 新增威脅資料
- 高風險統計
- 智能掃描摘要

### SandboxDrill

- 建立測試環境
- 建立 EICAR 測試檔
- 掃描並隔離
- 瀏覽隔離區
- 系統修復
- Reset demo environment

### Quarantine Manager

- 開啟隔離區管理視窗
- 顯示隔離中的威脅檔案
- 還原隔離檔案到 restored_files/
- 刪除隔離檔案
- 還原防呆確認
- 刪除防呆確認

### Run All Functions

- 會建立測試環境
- 會掃描並隔離
- 會瀏覽隔離區
- 會執行系統修復
- 不會刪除隔離區檔案
- 不會還原隔離區檔案

### Game Mode

- 手動遊戲模式 ON/OFF
- 遊戲模式 ON 時跳過掃描
- 無 psutil
- 無 process_iter

## Test Output

```text
=== Final All Functions Test ===

[1] SQLite whitelist manual add/remove
[Whitelist Add] True Added: trusted_app.exe
[Whitelist Duplicate] False Already exists.
[Whitelist Remove] True
[Whitelist Final] []

[2] Threat DB and smart scan
[Threat Add] True Threat added: Demo.Threat
[Threat Count] 6
[High Risk Count] 2

[3] Sandbox create + scan + quarantine
[Created] ['temp_work/Virus.Win32.Eicar', 'temp_work/normal_file.txt']
[Scan] Quarantined 1 item(s).
[Quarantine] ['1781971304_Virus.Win32.Eicar']

[4] Quarantine manager restore
[Restore] True Restored quarantine file to: restored_files/Virus.Win32.Eicar
[Restored Exists] True
[Quarantine After Restore] []

[5] Quarantine manager delete
[Delete] True Deleted quarantine file: 1781971304_Virus.Win32.Eicar
[Quarantine After Delete] []

[6] Run All safe behavior: no delete and no restore
[Run All Scan] Quarantined 1 item(s).
[Run All Quarantine Before] ['1781971304_Virus.Win32.Eicar']
[Run All Quarantine After] ['1781971304_Virus.Win32.Eicar']
[Run All Restored Folder Exists] False
[Recovery Steps] 4

[7] Manual game mode ON skips scan
[Game Scan] Game mode is ON. Scan skipped for performance.
[Game Mode] True
[Game Quarantine] []

[8] Reset demo environment
[Reset] True
[Quarantine Exists] True

=== Result ===
Manual whitelist remove: True
Duplicate whitelist blocked: True
Normal quarantined: 1
Restore ok: True
Delete ok: True
Run All kept quarantine: True
Run All did not restore: True
Manual game mode skipped: True
Reset ok: True
PASS

```

## STDERR Note

```text
Spreadsheet runtime warmup failed during python startup
Traceback (most recent call last):
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/generated/interface/models.py", line 30820, in hydrate_crdt_from_proto
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/remote.py", line 749, in __call__
  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/client.py", line 150, in call
artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.

```
